import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AulaPage } from './aula';

@NgModule({
  declarations: [
    AulaPage,
  ],
  imports: [
    IonicPageModule.forChild(AulaPage),
  ],
})
export class AulaPageModule {}
